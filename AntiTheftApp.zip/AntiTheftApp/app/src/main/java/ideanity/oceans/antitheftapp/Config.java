package ideanity.oceans.antitheftapp;

public class Config {
    public static final String EMAIL ="your email";
    public static final String PASSWORD ="your password";
}
